﻿{
    "sEmptyTable":     "数据表中没有可用的数据",
    "sInfo":           "显示从 _START_ 到 _END_ 总共 _TOTAL_ 条目",
    "sInfoEmpty":      "显示从 0 到 0 总共 0 条目",
    "sInfoFiltered":   "(从 _MAX_ 条目中筛选)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "显示 _MENU_ 条目",
    "sLoadingRecords": "正在加载...",
    "sProcessing":     "正在处理...",
    "sSearch":         "搜索：",
    "sZeroRecords":    "未找到匹配的记录",
    "oPaginate": {
        "sFirst":    "首页",
        "sLast":     "末页",
        "sNext":     "下页",
        "sPrevious": "上页"
    },
    "oAria": {
        "sSortAscending":  ": 升序排序",
        "sSortDescending": ": 降序排序"
    }
}