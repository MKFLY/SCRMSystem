<?php
// created: 2018-01-17 12:50:09
$dictionary["mkk_myCompany"]["fields"]["mkk_mycompany_am_projecttemplates"] = array (
  'name' => 'mkk_mycompany_am_projecttemplates',
  'type' => 'link',
  'relationship' => 'mkk_mycompany_am_projecttemplates',
  'source' => 'non-db',
  'module' => 'AM_ProjectTemplates',
  'bean_name' => 'AM_ProjectTemplates',
  'side' => 'right',
  'vname' => 'LBL_MKK_MYCOMPANY_AM_PROJECTTEMPLATES_FROM_AM_PROJECTTEMPLATES_TITLE',
);
