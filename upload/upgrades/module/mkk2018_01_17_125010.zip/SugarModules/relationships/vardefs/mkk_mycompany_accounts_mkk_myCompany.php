<?php
// created: 2018-01-17 12:50:09
$dictionary["mkk_myCompany"]["fields"]["mkk_mycompany_accounts"] = array (
  'name' => 'mkk_mycompany_accounts',
  'type' => 'link',
  'relationship' => 'mkk_mycompany_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_MKK_MYCOMPANY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
