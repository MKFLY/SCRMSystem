<?php
// created: 2018-01-17 12:50:09
$dictionary["mkk_myCompany"]["fields"]["mkk_mycompany_project"] = array (
  'name' => 'mkk_mycompany_project',
  'type' => 'link',
  'relationship' => 'mkk_mycompany_project',
  'source' => 'non-db',
  'module' => 'Project',
  'bean_name' => 'Project',
  'side' => 'right',
  'vname' => 'LBL_MKK_MYCOMPANY_PROJECT_FROM_PROJECT_TITLE',
);
