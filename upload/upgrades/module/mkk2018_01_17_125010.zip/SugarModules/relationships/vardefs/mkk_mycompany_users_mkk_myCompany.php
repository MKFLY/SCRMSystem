<?php
// created: 2018-01-17 12:50:09
$dictionary["mkk_myCompany"]["fields"]["mkk_mycompany_users"] = array (
  'name' => 'mkk_mycompany_users',
  'type' => 'link',
  'relationship' => 'mkk_mycompany_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_MKK_MYCOMPANY_USERS_FROM_USERS_TITLE',
);
