<?php
$popupMeta = array (
    'moduleMain' => 'mkk_myCompany',
    'varName' => 'mkk_myCompany',
    'orderBy' => 'mkk_mycompany.name',
    'whereClauses' => array (
  'name' => 'mkk_mycompany.name',
  'billing_address_city' => 'mkk_mycompany.billing_address_city',
  'phone_office' => 'mkk_mycompany.phone_office',
),
    'searchInputs' => array (
  0 => 'name',
  1 => 'billing_address_city',
  2 => 'phone_office',
  3 => 'industry',
),
    'searchdefs' => array (
),
);
